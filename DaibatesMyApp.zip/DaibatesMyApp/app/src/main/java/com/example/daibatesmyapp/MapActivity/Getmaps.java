package com.example.daibatesmyapp.MapActivity;

public class Getmaps {
    private String head;
    private String lati;
    private String longti;
    private String tel;



    public Getmaps(){

    }
    public Getmaps(String HTitle, String LatiContentv ,String LongtiContentv1, String Tel) {
        head = HTitle;
        lati = LatiContentv;
        longti = LongtiContentv1;
        tel = Tel;


    }

    public String gethospitalname() {
        return head;
    }
    public void sethospitalname(String head) {
        this.head = head;
    }



    public String getLati() {
        return lati;
    }
    public void setLati(String lati) {
        this.lati = lati;
    }

    public String getLongti() {
        return longti;
    }
    public void setLongti(String longti) {
        this.longti = longti;
    }


    public String getTel() {
        return tel;
    }
    public void setTel(String tel) {
        this.tel = tel;
    }
}
