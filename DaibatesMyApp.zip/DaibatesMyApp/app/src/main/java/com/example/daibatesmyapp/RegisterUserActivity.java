package com.example.daibatesmyapp;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.daibatesmyapp.GetFirebase.UserRegister;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class RegisterUserActivity extends AppCompatActivity {

    private EditText edUser;
    private EditText edPass;
    private RadioGroup edSex;
    private TextView edBirthday;
    private EditText edEmail;
    private EditText edTel;
    private Button btRegis;
    private static final String TAG = "RegisterUserActivity";
    ProgressDialog progressDialog;
    FirebaseAuth auth;
    DatabaseReference databaseUserRegister;
    private String test;
    String gender ="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        databaseUserRegister = FirebaseDatabase.getInstance().getReference("users");
        setTitle("                สมัครสมาชิก");
        //getSupportActionBar().hide();
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        auth = FirebaseAuth.getInstance();
        edUser = (EditText) findViewById(R.id.edUserRe);
        edPass = (EditText) findViewById(R.id.edPassRe);
        edSex = (RadioGroup) findViewById(R.id.edSex);
        final RadioButton checkedRadiomale = ( RadioButton ) RegisterUserActivity.this.findViewById (R.id.male);
        RadioButton checkedRadiofemale = ( RadioButton ) RegisterUserActivity.this.findViewById (R.id.female);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        edSex.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if(checkedRadiomale.isChecked())
                {
                    gender = "male";
                }
                else {
                   gender = "female";
                }
            }
        });

        edBirthday = (TextView) findViewById(R.id.edDate);
        Calendar cal = Calendar.getInstance();
        final int year = cal.get(cal.YEAR);
        final int month = cal.get(cal.MONTH);
        final int day = cal.get(cal.DAY_OF_MONTH);
        edBirthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datepicker = new DatePickerDialog(RegisterUserActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        edBirthday.setText(dayOfMonth + "/" + (month + 1) + "/" + year);
                    }
                }, year, month, day);
                datepicker.show();
            }
        });
        edEmail = (EditText) findViewById(R.id.edEmail);
        edTel = (EditText) findViewById(R.id.edTel);
        btRegis = (Button) findViewById(R.id.btRegis);




        btRegis.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                userRegister();

                String user = edUser.getText().toString();
                String pass = edPass.getText().toString();
                String sex = gender;
                String birthday = edBirthday.getText().toString();
                String email = edEmail.getText().toString();
                String tel = edTel.getText().toString();

                if (user.matches("")) {
                    edUser.setError("กรุณากรอกชื่อผู้ใช้");
                } else if (pass.matches("")) {
                    edPass.setError("กรุณากรอกรหัสผ่าน");
                }
//                else if (sex.matches("")) {
//                   // edSex.setError("กรุณาระบุ เพศ ");
//                }
                else if (pass.length() < 8 || pass.length() > 16) {
                    edPass.setError("กรุณากรอกรหัส 8-16 ตัวอักษร");
                }  else if (birthday.matches("")) {
                    edBirthday.setError("กรุณาเลือกวันเกิด");
                } else if (!email.matches("[a-zA-Z0-9._-]+[@]+[a-zA-Z]+[.]+[a-zA-Z.]+")) {
                    edEmail.setError("กรุณากรอกอีเมล");
                } else if (tel.length() < 9 || tel.length() > 11) {
                    edTel.setError("กรุณากรอกเบอร์โทรศัพท์");
                } else {
                    // checkUserForm();
                }

            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, MainActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void addUserRegister(){
        String addemail = edEmail.getText().toString().trim();
        String addusername = edUser.getText().toString().trim();
        String addpassword = edPass.getText().toString().trim();
        String addsex = gender;
        String addbirthday = edBirthday.getText().toString().trim();
        String addtell = edTel.getText().toString().trim();

        String id = test;

        UserRegister userRegister = new UserRegister(id,addemail,addusername,addtell,addpassword,addsex,addbirthday);
        databaseUserRegister.child(id).setValue(userRegister);
        Toast.makeText(this,"สมัครสมาชิกสำเร็จ",Toast.LENGTH_LONG).show();


        //        if(!TextUtils.isEmpty(addemail)){
//
//        }else {
//            Toast.makeText(this,"You sho")
//        }

    }

    private void showDialog() {
        if (!progressDialog.isShowing())
            progressDialog.show();
        progressDialog.setMessage("กรุณารอ...");
    }

    private void hideDialog() {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }

    private void userRegister() {
        if (TextUtils.isEmpty(edUser.getText()) || TextUtils.isEmpty(edPass.getText())
                || TextUtils.isEmpty(edPass.getText())
                 || (TextUtils.isEmpty(edBirthday.getText())
                ||(TextUtils.isEmpty(edEmail.getText()) || TextUtils.isEmpty(edTel.getText())))){
            Toast.makeText(RegisterUserActivity.this, "กรุณากรอกข้อมูลให้ครบ", Toast.LENGTH_SHORT).show();
        } else {
            showDialog();

            auth.createUserWithEmailAndPassword(edEmail.getText().toString(), edPass.getText().toString())

                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            Log.d(TAG, "onComplete: "+task.getException());
                            if (task.isSuccessful()) {
                                hideDialog();
                                test = auth.getCurrentUser().getUid();
                                addUserRegister();
                                Intent intent = new Intent(RegisterUserActivity.this, MainActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);

                                finish();
                            } else {
                                hideDialog();
                                Toast.makeText(RegisterUserActivity.this, "สมัครสมาชิกไม่สำเร็จ", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });

        }

    }
}

