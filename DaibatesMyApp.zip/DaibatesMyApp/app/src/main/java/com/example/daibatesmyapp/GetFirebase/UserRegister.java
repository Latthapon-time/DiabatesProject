package com.example.daibatesmyapp.GetFirebase;

public class UserRegister {

    String userId;
    String email;
    String user_name;
    String tell;
    String password;
    String sex;
    String birthday;

    public UserRegister(){

    }

    public UserRegister(String userId, String email, String user_name, String tell, String password, String sex, String birthday) {
        this.userId = userId;
        this.email = email;
        this.user_name = user_name;
        this.tell = tell;
        this.password = password;
        this.sex = sex;
        this.birthday = birthday;
    }

    public String getUserId() {

        return userId;
    }

    public String getEmail() {

        return email;
    }

    public String getUser_name() {

        return user_name;
    }

    public String getTell() {

        return tell;
    }

    public String getPassword() {

        return password;
    }

    public String getSex() {

        return sex;
    }

    public String getBirthday() {

        return birthday;
    }
}
