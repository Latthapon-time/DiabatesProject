package com.example.daibatesmyapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.daibatesmyapp.reminder.AddReminder;
import com.example.daibatesmyapp.reminder.ViewReminder;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {

    private ConstraintLayout mcConstraintLayout;
    private ActionBarDrawerToggle mToggle;
    private TextView textView;
    private TextView txtemail;
    private Button button;
    FirebaseAuth auth;
    DatabaseReference mDatabaseReference;
    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        auth = FirebaseAuth.getInstance();
        //.getCurrentUser().getUid();
        textView = findViewById(R.id.uidtxt);
        txtemail = findViewById(R.id.emailtxt);
        button = findViewById(R.id.btuId);

        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        txtemail.setText(user.getEmail());
        String uid = auth.getCurrentUser().getUid();
        textView.setText(uid);
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

//        button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                String uid = auth.getCurrentUser().getUid();
//                textView.setText(uid);
//                mDatabaseReference= FirebaseDatabase.getInstance().getReference("users");
//                mDatabaseReference.addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                        UserRegister user = dataSnapshot.getValue(UserRegister.class);
//
//
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError databaseError) {
//
//                    }
//                });
//
//
//            }
//        });
        mcConstraintLayout = (ConstraintLayout) findViewById(R.id.constrain);


    }

    public void LL(View view) {
        Intent inte = new Intent(this, Main2Activity.class);
        startActivity(inte);
    }

    public void btnlunch(View view) {
        Intent inte = new Intent(this, AddReminder.class);
        startActivity(inte);
    }

    public void btnviewRemider(View view) {

        Intent inte = new Intent(this, ViewReminder.class);
        startActivity(inte);
    }
}