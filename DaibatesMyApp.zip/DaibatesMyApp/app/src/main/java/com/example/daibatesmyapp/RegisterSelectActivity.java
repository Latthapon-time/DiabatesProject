package com.example.daibatesmyapp;

public class RegisterSelectActivity {
}
