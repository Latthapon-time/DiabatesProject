package com.example.daibatesmyapp.reminder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Path;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.MapActivity.Viewmaps;
import com.example.daibatesmyapp.Noti.UinotiActivity;
import com.example.daibatesmyapp.Noti.ViewNotiActivity;
import com.example.daibatesmyapp.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewReminder extends AppCompatActivity {
    private RecyclerView FindFriendsRecyclerList;
    private DatabaseReference UsersRef;
    private FirebaseAuth auth = FirebaseAuth.getInstance();
    private Query query ;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_reminder);
        setTitle("    รายการบันทึกค่าน้ำตาลในเลือด");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        UsersRef = FirebaseDatabase.getInstance().getReference().child("sugar_data").child(auth.getCurrentUser().getUid());
        //query = UsersRef.orderByChild(equalTo(auth.getCurrentUser().getUid());
//        query.addValueEventListener(new)


        FindFriendsRecyclerList = (RecyclerView) findViewById(R.id.myRecycleView);
        LinearLayoutManager m = new LinearLayoutManager(this);
        m.setReverseLayout(true);
        m.setStackFromEnd(true);
        FindFriendsRecyclerList.setLayoutManager(m);
        final BottomNavigationView navView = findViewById(R.id.bottomNavigationView2);
        Menu menu = navView.getMenu();
        MenuItem menuItem = menu.getItem(1);
        menuItem.setChecked(true);

        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem1) {
                switch (menuItem1.getItemId()) {
                    case R.id.navigation_home:


                        Toast.makeText(ViewReminder.this, "หน้าหลัก", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewReminder.this, HomeActivity.class));
                        break;
                    case R.id.navigation_dashboard:
                        Toast.makeText(ViewReminder.this, "บันทึกค่าน้ำตาล", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewReminder.this, ViewReminder.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_notifications:
                        Toast.makeText(ViewReminder.this, "เตือนการกินยา", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewReminder.this, UinotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_viewnoti:
                        Toast.makeText(ViewReminder.this, "รายการที่บันทึกแจ้งเตือน", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewReminder.this, ViewNotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_map:
                        Toast.makeText(ViewReminder.this, "แผนที่", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewReminder.this, Viewmaps.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                }
                return false;
            }
        });
    }



    @Override
    public void onBackPressed() {

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onStart()
    {
        super.onStart();


        FirebaseRecyclerOptions<GetRemider> options =
                new FirebaseRecyclerOptions.Builder<GetRemider>()
                        .setQuery(UsersRef.orderByChild("sugar_date").limitToLast(100), GetRemider.class)

                        .build();

        FirebaseRecyclerAdapter<GetRemider, FindFriendViewHolder> adapter =
                new FirebaseRecyclerAdapter<GetRemider, FindFriendViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull FindFriendViewHolder holder, final int position, @NonNull GetRemider model)
                    {


                      int p = position ;
                        holder.userName.setText(model.getSugar_level());
                        holder.userStatus.setText(model.getSugar_date());
                        holder.userschedul.setText(model.getSchedul());


                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                              //  int temp = position +6;
                                final String reminderId = getRef(position).getKey();
                                Intent intent = new Intent(ViewReminder.this, Upandremove.class);
                                intent.putExtra("reminderId", reminderId);
                                startActivity(intent);
                            }
                        });




                    }

                    @NonNull
                    @Override
                    public FindFriendViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
                    {
                        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_remider, viewGroup, false);
                        FindFriendViewHolder viewHolder = new FindFriendViewHolder(view);
                     //   i = i -6;
                        return viewHolder;
                    }
                };

        FindFriendsRecyclerList.setAdapter(adapter);

        adapter.startListening();
    }


    //Search

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {


        getMenuInflater().inflate(R.menu.searchsugar, menu);
        MenuItem menuItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) menuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Query firebaseSearchQuery = UsersRef.orderByChild("sugar_date").startAt(newText).endAt(newText + "\uf8ff");
               // firebaseSearchQuery.getFilter().filter(newText);
                return false;
            }
        });


        return super.onCreateOptionsMenu(menu);
    }











    public static class FindFriendViewHolder extends RecyclerView.ViewHolder
    {

        TextView userName, userStatus, userschedul;



        public FindFriendViewHolder(@NonNull View itemView)
        {
            super(itemView);

            userName = itemView.findViewById(R.id.levelSugar);
            userStatus = itemView.findViewById(R.id.view_head);
            userschedul = itemView.findViewById(R.id.view_ReminderContent);

        }
    }
}