package com.example.daibatesmyapp.User;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.MainActivity;
import com.example.daibatesmyapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Deleteuser extends AppCompatActivity {

    TextInputLayout tname,temail;
    TextInputEditText ename,eemail;
    Button btnDEuser;

    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser,firebaseUser1;
    DatabaseReference mDatabaseReference = FirebaseDatabase.getInstance().getReference("users");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deleteuser);
        tname = (TextInputLayout) findViewById(R.id.tename);
        temail = (TextInputLayout) findViewById(R.id.temail);
        btnDEuser = (Button) findViewById(R.id.btndeuser);

        ename = (TextInputEditText) findViewById(R.id.editText1);
        eemail=(TextInputEditText) findViewById(R.id.editText2);
        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();
        firebaseUser1 =firebaseAuth.getCurrentUser();


        tname.setHint("username");
        temail.setHint("email");

        String uid = firebaseUser.getUid();
        mDatabaseReference.child(uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String fnname = dataSnapshot.child("user_name").getValue().toString();
                ename.setText(fnname);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        eemail.setText(firebaseUser.getEmail());


        btnDEuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(Deleteuser.this);
                dialog.setTitle("ลบบัญชีผู้ใช้");
                dialog.setMessage("คุณต้องการที่จะลบบัญชี ใช่หรือไม่");
                dialog.setPositiveButton("ใช่", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        firebaseUser1.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    Toast.makeText(Deleteuser.this, "ลบบัญชีสำเร็จ", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(Deleteuser.this,MainActivity.class);
                                    startActivity(intent);
                                }else {
                                    Toast.makeText(Deleteuser.this, "ลบบัญชีไม่สำเร็จ", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                });

                dialog.setNegativeButton("ไม่", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.dismiss();
                    }
                });

                AlertDialog alertDialog = dialog.create();
                alertDialog.show();
            }
        });

    }
}
