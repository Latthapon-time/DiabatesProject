package com.example.daibatesmyapp.User;

public class Deta {
    public String d;
}
