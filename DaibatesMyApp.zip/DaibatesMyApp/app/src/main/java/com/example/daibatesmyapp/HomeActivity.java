package com.example.daibatesmyapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import com.example.daibatesmyapp.ContentFrag.ContentActivity;
import com.example.daibatesmyapp.GetFirebase.CreateNoti;
import com.example.daibatesmyapp.MapActivity.MapsActivity;
import com.example.daibatesmyapp.MapActivity.Viewmaps;
import com.example.daibatesmyapp.Noti.MedicalAdd;
import com.example.daibatesmyapp.Noti.UinotiActivity;
import com.example.daibatesmyapp.Noti.ViewNotiActivity;
import com.example.daibatesmyapp.User.Deleteuser;
import com.example.daibatesmyapp.addsuga.Addsuga2Activity;
import com.example.daibatesmyapp.addsuga.Addsuga3Activity;
import com.example.daibatesmyapp.addsuga.Addsuga4Activity;
import com.example.daibatesmyapp.addsuga.Addsuga5Activity;
import com.example.daibatesmyapp.addsuga.Addsuga6Activity;
import com.example.daibatesmyapp.addsuga.Addsuga7Activity;
import com.example.daibatesmyapp.reminder.AddReminder;
import com.example.daibatesmyapp.reminder.ViewReminder;

import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.core.view.GravityCompat;
import androidx.navigation.ui.AppBarConfiguration;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private AppBarConfiguration mAppBarConfiguration;
    private FirebaseAuth auth;
    final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    DatabaseReference mDatabaseReference = FirebaseDatabase.getInstance().getReference("users");
    //ตัวแปรแสดงค่า username และ email หน้า navigationdrawer
    TextView textusername, textemail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = findViewById(R.id.toolbar);


        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("                    หน้าหลัก");
        final BottomNavigationView navView = findViewById(R.id.bottomNavigationView2);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view1);
        navigationView.setNavigationItemSelectedListener(this);
        View v = navigationView.getHeaderView(0);

        textusername = v.findViewById(R.id.txtusername);
        textemail = v.findViewById(R.id.txtemail);
        String uid = user.getUid();
        mDatabaseReference.child(uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                try {
                String fnname = dataSnapshot.child("user_name").getValue().toString();

                textusername.setText(fnname);
                textemail.setText(user.getEmail());
                }catch (Exception e) {
                    Toast.makeText(HomeActivity.this, "ไม่สามารถใช้งานได้", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(HomeActivity.this, MainActivity.class));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        // setContentView(R.layout.activity_home);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.


        navigationView.setNavigationItemSelectedListener(this);
//        Menu menu = navView.getMenu();
//        MenuItem menuItem = menu.getItem(1);
//        menuItem.setChecked(true);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem1) {
                switch (menuItem1.getItemId()) {
                    case R.id.navigation_home:


                        Toast.makeText(HomeActivity.this, "หน้าหลัก", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomeActivity.this, HomeActivity.class));
                        break;
                    case R.id.navigation_dashboard:
                        Toast.makeText(HomeActivity.this, "บันทึกค่าน้ำตาล", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomeActivity.this, ViewReminder.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_notifications:
                        Toast.makeText(HomeActivity.this, "เตือนการกินยา", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomeActivity.this, UinotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_viewnoti:
                        Toast.makeText(HomeActivity.this, "รายการที่บันทึกแจ้งเตือน", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomeActivity.this, ViewNotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_map:
                        Toast.makeText(HomeActivity.this, "แผนที่", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(HomeActivity.this, Viewmaps.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                }
                return false;
            }
        });

}
        @Override
        public void onBackPressed () {

        }

        private void fetchData (String u_id){
            mDatabaseReference.child(u_id).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    //   String fnname = dataSnapshot.child("user_name").getValue().toString();
//                textusername.setText(fnname);
//                textemail.setText(user.getEmail());
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        @Override
        public boolean onCreateOptionsMenu (Menu menu){
            // Inflate the menu; this adds items to the action bar if it is present.
            getMenuInflater().inflate(R.menu.home, menu);
            return true;
        }

        @Override
        public boolean onOptionsItemSelected (MenuItem item){
            // Handle action bar item clicks here. The action bar will
            // automatically handle clicks on the Home/Up button, so long
            // as you specify a parent activity in AndroidManifest.xml.
            int id = item.getItemId();
            switch (item.getItemId()) {
//            case R.id.action_about:
//                // About option clicked.
//                return true;
                case R.id.action_settings1:
                    startActivity(new Intent(HomeActivity.this, Deleteuser.class));
                    finish();
                    overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

                    // Settings option clicked.
                    return true;
                default:
                    return super.onOptionsItemSelected(item);
            }

            //noinspection SimplifiableIfStatement

            // return super.onOptionsItemSelected(item);
        }

        public boolean onNavigationItemSelected (MenuItem item){
            // Handle navigation view item clicks here.
            int id = item.getItemId();

            if (id == R.id.userprofile) {

                startActivity(new Intent(HomeActivity.this, ProfileActivity.class));
                finish();
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);


            } else if (id == R.id.sigoutuser) {
                signout();
            }
//
//           // startActivity(new Intent(MainActivity.this,AboutUs.class));
//
            else if (id == R.id.nav_saves) {
                startActivity(new Intent(HomeActivity.this, ContentActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

            } else if (id == R.id.nav_slideshow) {
                startActivity(new Intent(HomeActivity.this, AboutActivity.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

            } else if (id == R.id.nav_addmedical) {
                startActivity(new Intent(HomeActivity.this, MedicalAdd.class));
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left);

    }

//        }  else if (id == R.id.navigation_map) {


//            auth.signOut();
//            startActivity(new Intent(PatientActivity.this,LoginActivity.class));
//            finish();

//            bottomNavigationView2.setOnClickListener(new View.OnClickListener() {
//
//                @Override
//                public void onClick(View view) {
//
//                }
//            });
//        }

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);


            drawer.closeDrawer(GravityCompat.START);
            return true;
        }



    private void signout() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(HomeActivity.this);
        alertDialog.setTitle("ออกจากระบบ");

        alertDialog.setMessage("คุณต้องการออกจากระบบใช่หรือไม่");

        alertDialog.setPositiveButton("ใช่",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        auth.getInstance().signOut();
                        Intent in = new Intent(HomeActivity.this, MainActivity.class);
                        in.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(in);
                    }
                });


        alertDialog.setNegativeButton("ไม่",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        Toast.makeText(getApplicationContext(),
                                ".", Toast.LENGTH_SHORT)
                                .show();
                        dialogInterface.cancel();
                    }
                });


        alertDialog.show();
    }


    public void btnviewRemider(View view) {

        Intent inte = new Intent(this, ViewReminder.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void btnlunch(View view) {
        Intent inte = new Intent(this, AddReminder.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void btnlunch2(View view) {
        Intent inte = new Intent(this, Addsuga2Activity.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void btnlunch3(View view) {
        Intent inte = new Intent(this, Addsuga3Activity.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void btnlunch4(View view) {
        Intent inte = new Intent(this, Addsuga4Activity.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void btnlunch5(View view) {
        Intent inte = new Intent(this, Addsuga5Activity.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void btnlunch6(View view) {
        Intent inte = new Intent(this, Addsuga6Activity.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    public void btnlunch7(View view) {
        Intent inte = new Intent(this, Addsuga7Activity.class);
        startActivity(inte);
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }


//    @Override
//    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
//        return false;
//    }
}

