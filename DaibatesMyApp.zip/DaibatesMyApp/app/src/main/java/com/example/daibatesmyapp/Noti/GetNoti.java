package com.example.daibatesmyapp.Noti;

public class GetNoti {
    private String head;
    private String remindercontent;
    private String today;



    public GetNoti(){

    }
    public GetNoti(String ReminderTitle, String ReminderContent ,String Today) {
        head = ReminderTitle;
        remindercontent = ReminderContent;
        today = Today;


    }

    public String getmedical() {
        return head;
    }
    public void setmedical(String head) {
        this.head = head;
    }

    public String getmedicalabout() {
        return remindercontent;
    }
    public void setmedicalabout(String remindercontent) {
        this.remindercontent = remindercontent;
    }

    public String getdate() {
        return today;
    }
    public void setdate(String today) {
        this.today = today;
    }
}
