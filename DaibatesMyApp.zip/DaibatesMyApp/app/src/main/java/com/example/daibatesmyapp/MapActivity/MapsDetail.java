package com.example.daibatesmyapp.MapActivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MapsDetail extends AppCompatActivity {
    private Button mapsto;
    private TextView nameHospital, lati , longti ,telHospital;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    private String reminderId;
    private boolean isExist;
    static public String latilati, longtilongti;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps_detail);
        setTitle("  โรงพยาบาลที่เกี่ยวกับโรคเบาหวาน");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //textรับข้อมูล จาก list โรงพยาบาล
        nameHospital = findViewById(R.id.titleup);
        lati = findViewById(R.id.diaryup);
        longti = findViewById(R.id.titleup2);
        telHospital = findViewById(R.id.titleup3);

        mapsto = findViewById(R.id.toto);

        try {
            reminderId = getIntent().getStringExtra("reminderId");
            if (!reminderId.trim().equals("")) {
                isExist = true;
            } else {
                isExist = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("hospital");
        putData();

        //เมื่อกดปุ่ม
        mapsto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapstogo();
            }
        });
    }

    @Override
    public void onBackPressed() {

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, Viewmaps.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void mapstogo() {
        Intent inte = new Intent(this, MapsActivity.class);
        startActivity(inte);
    }

    private void putData() {
        if (isExist) {
            if (reminderId != null) {
                databaseReference.child(reminderId).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild("hospitalname") && dataSnapshot.hasChild("lati")&& dataSnapshot.hasChild("longti")) {
                            String titles = dataSnapshot.child("hospitalname").getValue().toString();
                            String tel = dataSnapshot.child("tel").getValue().toString();
                            latilati = dataSnapshot.child("lati").getValue().toString();
                            longtilongti = dataSnapshot.child("longti").getValue().toString();

                            nameHospital.setText(titles);
                           // tel.setText(tel);
                            lati.setText(latilati);
                            longti.setText(longtilongti);
                            telHospital.setText(tel);

                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        }
    }
}
