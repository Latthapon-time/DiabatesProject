package com.example.daibatesmyapp.Noti;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.work.WorkManager;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;
import com.example.daibatesmyapp.reminder.Upandremove;
import com.example.daibatesmyapp.reminder.ViewReminder;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ClickcCancleNoti extends AppCompatActivity {

    private Button delete, back1;
    private TextView upHead, upReminder;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    private String reminderId;
    private boolean isExist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clickc_cancle_noti);
        setTitle("              รายการแจ้งเตือนยา");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        upHead = (TextView) findViewById(R.id.titleup);
        upReminder = (TextView) findViewById(R.id.diaryup);

        delete =(Button)findViewById(R.id.removebtn) ;
        back1 = (Button) findViewById(R.id.back1);



        try {
            reminderId = getIntent().getStringExtra("reminderId");
            if (!reminderId.trim().equals("")) {
                isExist = true;
            } else {
                isExist = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("medication_plan").child(firebaseAuth.getCurrentUser().getUid());
        putData();


        delete.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                deletenoti();
            }
        });



        back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ClickcCancleNoti.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void putData() {

        if (isExist) {
            if (reminderId != null) {
                databaseReference.child(reminderId).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild("medical") && dataSnapshot.hasChild("medicalabout")) {
                            String titles = dataSnapshot.child("medical").getValue().toString();
                            String contents = dataSnapshot.child("medicalabout").getValue().toString();

                            upHead.setText(titles);
                            upReminder.setText(contents);
                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        }
    }



    private void deletenoti(){
        if (reminderId != null) {
            databaseReference.child(reminderId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(ClickcCancleNoti.this, "Noti Deleted", Toast.LENGTH_SHORT).show();
                        switch (upHead.getText().toString()){
                            case "Metformin" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG1");
                                Intent intent = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                                finish();
                                break;
                            case "Repaglinide" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG2");
                                Intent intent2 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent2);
                                finish();
                                break;
                            case "DPP-4Inhibitors" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG3");
                                Intent intent3 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent3);
                                finish();
                                break;
                            case "Acarbose" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG4");
                                Intent intent4 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent4);
                                finish();
                                break;
                            case "Bile Acid Sequestrants" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG5");
                                Intent intent5 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent5);
                                finish();
                                break;
                            case "Sulfonylurea" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG6");
                                Intent intent6 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent6);
                                finish();
                                break;
                            case "alphaglucidase" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG7");
                                Intent intent7 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent7);
                                finish();
                                break;
                            case "Troglitazone" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG8");
                                Intent intent8 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent8);
                                finish();
                                break;
                            case "Meglitinides" :
                                WorkManager.getInstance().cancelAllWorkByTag("CANCLETAG9");
                                Intent intent9 = new Intent(ClickcCancleNoti.this, ViewNotiActivity.class);
                                startActivity(intent9);
                                finish();
                                break;
                        }


                        finish();

                     //  reminderId ="no";


                    } else {
                        Log.e("UpdateandDelete", task.getException().toString());
                        Toast.makeText(ClickcCancleNoti.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }





}

