package com.example.daibatesmyapp.addsuga;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;
import com.example.daibatesmyapp.addsuga.Addsuga3Activity;
import com.example.daibatesmyapp.reminder.GetRemider;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Addsuga5Activity extends AppCompatActivity {

    private Button Add_btn,back2;
    private EditText txtdatesugaShedu, txtHead ,texttimeschedu;
    FirebaseAuth auth;
    DatabaseReference mDatabaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_reminder);
        getSupportActionBar().setTitle("               บันทึกค่าน้ำตาล");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        Add_btn = (Button) findViewById(R.id.add_btn);

        txtHead = (EditText) findViewById(R.id.Edittxt_Title);
        txtdatesugaShedu = (EditText) findViewById(R.id.Edittxt_diary);
        texttimeschedu = (EditText) findViewById(R.id.Edittxt_diary2);
        Date date  = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        DateFormat formatter1 = new SimpleDateFormat("HH:mm");
        String today = formatter.format(date);
        String todaytime = formatter1.format(date)+" ก่อนอาหารเย็น";
        txtdatesugaShedu.setText(today);
        texttimeschedu.setText(todaytime);

        auth =  FirebaseAuth.getInstance();

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("sugar_data").child(auth.getCurrentUser().getUid());

        Add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Sugar_level = txtHead.getText().toString().trim();
                String content = txtdatesugaShedu.getText().toString().trim();
                String schdutime = texttimeschedu.getText().toString().trim();

                if (!TextUtils.isEmpty(Sugar_level) && !TextUtils.isEmpty(content) && !TextUtils.isEmpty(schdutime)) {
                    CreateRemider();

                } else {
                    Snackbar.make(view, "กรุณากรอกข้อมูล", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

    }
    private void CreateRemider() {

        String Head = txtHead.getText().toString().trim();
        String reminder = txtdatesugaShedu.getText().toString().trim();
        String schedutime = texttimeschedu.getText().toString().trim();
        //check id + add
        if (auth.getCurrentUser() != null) {
            String id = mDatabaseReference.push().getKey();
            GetRemider Reminder = new GetRemider(Head,reminder,schedutime);
            mDatabaseReference.child(id).setValue(Reminder);
            txtHead.setText("");
            txtdatesugaShedu.setText("");
            Toast.makeText(Addsuga5Activity.this, "บันทึก " , Toast.LENGTH_SHORT).show();
            Intent newIntent = new Intent(Addsuga5Activity.this, HomeActivity.class);
            startActivity(newIntent);
        } else {
            Toast.makeText(this, "ผู้ใช้ไม่ได้ทำการล็อคอิน ", Toast.LENGTH_SHORT).show();
        }
    }
    public void backhome(View view) {
        Intent inte = new Intent(this, HomeActivity.class);
        startActivity(inte);
    }
}
