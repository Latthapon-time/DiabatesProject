package com.example.daibatesmyapp.Noti;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.daibatesmyapp.R;

import java.util.concurrent.TimeUnit;

import static com.example.daibatesmyapp.Noti.UinotiActivity.MEDICAL;
import static com.example.daibatesmyapp.Noti.UinotiActivity.MEDICAL2;
import static com.example.daibatesmyapp.Noti.UinotiActivity.diff;

public class StartNoti9Activity extends AppCompatActivity {
    public static final String TAG= "uniqueWork99";
    WorkManager workManager;
    Button btnStartPeriod, btnStartCancel;
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_noti9);
//รับค่า noti มาจากหน้า UI
        Toast.makeText(getApplicationContext(),"เริ่มทำการแจ้งเตือน"+diff,Toast.LENGTH_LONG).show();
        String title1 = MEDICAL;
        String des1 = MEDICAL2;
        //ส่งค่า noti เข้า api
        final Context context = getApplicationContext();
        Data data = new Data.Builder()
                .putString(MyWorker9.TASK_TITLE,title1)
                .putString(MyWorker9.TASK_DESC,des1)
                .build();
        workManager = WorkManager.getInstance(context);
        btnStartPeriod = findViewById(R.id.buttonEnqueue);
        btnStartCancel = findViewById(R.id.buttonCancel);
        textView = findViewById(R.id.textViewStatus);
        //
//        scheduleWork(hour,minute,diff);
        Constraints constraints = new Constraints.Builder()
                .setRequiresCharging(false)
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
        final PeriodicWorkRequest periodicWorkRequest9
                = new PeriodicWorkRequest.Builder(MyWorker3.class, 15, TimeUnit.MINUTES)
                .setInputData(data)
                .addTag("CANCLETAG9")
                .setConstraints(constraints)
                .setInitialDelay(diff,TimeUnit.MINUTES)
                .build();



        btnStartPeriod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getApplicationContext(),"เริ่มทำการแจ้งเตือน",Toast.LENGTH_LONG).show();
                workManager.enqueueUniquePeriodicWork(TAG,
                        ExistingPeriodicWorkPolicy.KEEP,
                        periodicWorkRequest9);
//

            }
        });
        btnStartCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                WorkManager.getInstance(context).cancelWorkById(periodicWorkRequest9.getId());

            }
        });


        WorkManager.getInstance(context).getWorkInfoByIdLiveData(periodicWorkRequest9.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(@Nullable WorkInfo workInfo) {


                        //Displaying the status into TextView
                        textView.append(workInfo.getState().name() + "\n");
                    }
                });

    }
}
