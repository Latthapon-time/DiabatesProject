package com.example.daibatesmyapp.GetFirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.daibatesmyapp.R;

public class CreateNoti extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_noti);
    }
}
