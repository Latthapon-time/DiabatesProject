package com.example.daibatesmyapp.reminder;

public class GetRemider {

        private String head;
        private String remindercontent;
        private String schedu;


        public GetRemider(){

        }
        public GetRemider(String ReminderTitle, String ReminderContent, String Schedu) {
            head = ReminderTitle;
            remindercontent = ReminderContent;
            schedu = Schedu;

        }

        public String getSugar_level() {
            return head;
        }
    public void setSugar_level(String head) {
        this.head = head;
    }

        public String getSugar_date() {
            return remindercontent;
        }
        public void setSugar_date(String remindercontent) {
        this.remindercontent = remindercontent;
    }

    public String getSchedul() {
        return schedu;
    }
    public void setSchedul(String schedu1) {
        this.schedu = schedu1;
    }


    }


