package com.example.daibatesmyapp.Noti;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MedicalAdd extends AppCompatActivity {

    EditText namemedication;
    Button buttonaddmedi;
    DatabaseReference mDatabaseReference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_add);
        getSupportActionBar().setTitle("               เพิ่มรายชื่อยา");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        namemedication = findViewById(R.id.Edittxt_Title);
        buttonaddmedi =findViewById(R.id.add_btn);

        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("addmedical");

        buttonaddmedi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Head = namemedication.getText().toString().trim();
                if(!TextUtils.isEmpty(Head)) {
                    String id = mDatabaseReference.push().getKey();
                   // String Head = namemedication.getText().toString().trim();
                    Get_nameMedical nameMedical = new Get_nameMedical(Head);
                    mDatabaseReference.child(id).setValue(nameMedical);
                    Snackbar.make(v, "เพิ่มสำเร็จ", Snackbar.LENGTH_SHORT).show();
                }else {
                    Snackbar.make(v, "ไม่สำเร็จ", Snackbar.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {

    }
}
