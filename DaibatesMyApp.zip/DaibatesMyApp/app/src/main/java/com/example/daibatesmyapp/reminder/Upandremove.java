package com.example.daibatesmyapp.reminder;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class Upandremove extends AppCompatActivity {
    private Button update,delete, back1;
    private EditText upHead, upReminder;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    private String reminderId;
    private boolean isExist;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upandremove);
        getSupportActionBar().setTitle("               บันทึกค่าน้ำตาล");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        upHead = (EditText) findViewById(R.id.titleup);
        upReminder = (EditText) findViewById(R.id.diaryup);
        update = (Button) findViewById(R.id.upbtn);
        delete =(Button)findViewById(R.id.removebtn) ;
        back1 = (Button) findViewById(R.id.back1);



        try {
            reminderId = getIntent().getStringExtra("reminderId");
            if (!reminderId.trim().equals("")) {
                isExist = true;
            } else {
                isExist = false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        firebaseAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("sugar_data").child(firebaseAuth.getCurrentUser().getUid());

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String Utitle = upHead.getText().toString().trim();
                String Ucontent = upReminder.getText().toString().trim();
                if (!TextUtils.isEmpty(Utitle) && !TextUtils.isEmpty(Ucontent)) {
                    updateReminder();
                } else {
                    Snackbar.make(v, "Please Fill empty fields", Snackbar.LENGTH_SHORT).show();
                }
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteReminder();
            }
        });
        putData();


        back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Upandremove.this, HomeActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public void putData() {

        if (isExist) {
            if (reminderId != null) {
                databaseReference.child(reminderId).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        if (dataSnapshot.hasChild("sugar_level") && dataSnapshot.hasChild("sugar_date")) {
                            String titles = dataSnapshot.child("sugar_level").getValue().toString();
                            String contents = dataSnapshot.child("sugar_date").getValue().toString();

                            upHead.setText(titles);
                            upReminder.setText(contents);
                        }

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        }
    }

    private  void updateReminder(){
        if (firebaseAuth.getCurrentUser() != null) {
            if (isExist) {
                if (reminderId != null) {
                    Map updateMap = new HashMap();
                    updateMap.put("sugar_level", upHead.getText().toString().trim());//*************
                    updateMap.put("sugar_date", upReminder.getText().toString().trim());

                    databaseReference.child(reminderId).updateChildren(updateMap);

                    Toast.makeText(this, "Reminder Update", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Upandremove.this, ViewReminder.class);
                    startActivity(intent);

                }
            }
        }
    }

    private void deleteReminder() {
        if (reminderId != null) {
            databaseReference.child(reminderId).removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(Upandremove.this, "Reminder Deleted", Toast.LENGTH_SHORT).show();
                        reminderId ="no";
                        Intent intent = new Intent(Upandremove.this, ViewReminder.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Log.e("UpdateandDelete", task.getException().toString());
                        Toast.makeText(Upandremove.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }





}
