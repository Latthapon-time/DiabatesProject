package com.example.daibatesmyapp.User;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import com.example.daibatesmyapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProfileUserActivity extends AppCompatActivity {
    
    EditText fnameValue,GenderValue,bloodgrpValue,AddressValue,phoneValue,profileDob;
    FirebaseAuth auth;

    DatabaseReference mdDatabaseReference = FirebaseDatabase.getInstance().getReference("users");
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_user);
        //เชื่อมไอดี
//        fnameValue=findViewById(R.id.FnameValue);
//        //EditProfile=findViewById(R.id.EditProfile);
//        GenderValue=findViewById(R.id.genderValue);
//        bloodgrpValue=findViewById(R.id.bloodgrpValue);
//        AddressValue=findViewById(R.id.AddressValue);
//        phoneValue=findViewById(R.id.MobileValue);
//        //Update=findViewById(R.id.Update);
//        gender=findViewById(R.id.Gender);
//        //bg=findViewById(R.id.Bloodgrp);
//        profileDob=findViewById(R.id.profileDob);
//        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//        String uid= user.getUid();
//
//        fetchData(uid);
    }

//    private void fetchData(String id)
//    {
//        mdDatabaseReference.child(id).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                String fname=dataSnapshot.child("user_name").getValue().toString();
//                String gender=dataSnapshot.child("sex").getValue().toString();
//                String phone=dataSnapshot.child("tell").getValue().toString();
//
//
//
//                fnameValue.setText(fname);
//                phoneValue.setText(phone);
//                GenderValue.setText(gender);
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//
//            }
//        });
//    }
}
