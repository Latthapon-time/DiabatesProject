package com.example.daibatesmyapp.Noti;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.MapActivity.Viewmaps;
import com.example.daibatesmyapp.R;
import com.example.daibatesmyapp.addsuga.Addsuga3Activity;
import com.example.daibatesmyapp.reminder.ViewReminder;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ViewNotiActivity extends AppCompatActivity {
    private RecyclerView FindFriendsRecyclerList;
    private DatabaseReference UsersRef;
    private FirebaseAuth auth = FirebaseAuth.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_noti);
        setTitle("              รายการแจ้งเตือนยา");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        UsersRef = FirebaseDatabase.getInstance().getReference().child("medication_plan").child(auth.getCurrentUser().getUid());

        FindFriendsRecyclerList = (RecyclerView) findViewById(R.id.myRecycleView);
        FindFriendsRecyclerList.setLayoutManager(new LinearLayoutManager(this));

        //ปุ่ม
        final BottomNavigationView navView = findViewById(R.id.bottomNavigationView2);
        Menu menu = navView.getMenu();
        MenuItem menuItem = menu.getItem(3);
        menuItem.setChecked(true);

        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem1) {
                switch (menuItem1.getItemId()) {
                    case R.id.navigation_home:


                        Toast.makeText(ViewNotiActivity.this, "หน้าหลัก", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewNotiActivity.this, HomeActivity.class));
                        break;
                    case R.id.navigation_dashboard:
                        Toast.makeText(ViewNotiActivity.this, "บันทึกค่าน้ำตาล", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewNotiActivity.this, ViewReminder.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_notifications:
                        Toast.makeText(ViewNotiActivity.this, "เตือนการกินยา", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewNotiActivity.this, UinotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_viewnoti:
                        Toast.makeText(ViewNotiActivity.this, "รายการที่บันทึกแจ้งเตือน", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewNotiActivity.this, ViewNotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_map:
                        Toast.makeText(ViewNotiActivity.this, "แผนที่", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(ViewNotiActivity.this, Viewmaps.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                }
                return false;
            }
        });
    }


    @Override
    public void onBackPressed() {

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    protected void onStart()
    {
        super.onStart();

        FirebaseRecyclerOptions<GetNoti> options =
                new FirebaseRecyclerOptions.Builder<GetNoti>()
                        .setQuery(UsersRef, GetNoti.class)
                        .build();

        FirebaseRecyclerAdapter<GetNoti, FindFriendViewHolder> adapter =
                new FirebaseRecyclerAdapter<GetNoti, FindFriendViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull FindFriendViewHolder holder, final int position, @NonNull GetNoti model)
                    {
                        holder.userName.setText(model.getmedical());
                        holder.userStatus.setText(model.getmedicalabout());
                        holder.today.setText(model.getdate());

                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                final String reminderId = getRef(position).getKey();
                                Intent intent = new Intent(ViewNotiActivity.this, ClickcCancleNoti.class);
                                intent.putExtra("reminderId", reminderId);
                                startActivity(intent);
                                finish();
                            }
                        });




                    }

                    @NonNull
                    @Override
                    public FindFriendViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
                    {
                        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.list_noti, viewGroup, false);
                        FindFriendViewHolder viewHolder = new FindFriendViewHolder(view);
                        return viewHolder;
                    }
                };

        FindFriendsRecyclerList.setAdapter(adapter);

        adapter.startListening();
    }



    public static class FindFriendViewHolder extends RecyclerView.ViewHolder
    {

        TextView userName, userStatus ,today;



        public FindFriendViewHolder(@NonNull View itemView)
        {
            super(itemView);

            userName = itemView.findViewById(R.id.view_head);
            userStatus = itemView.findViewById(R.id.view_ReminderContent);
            today = itemView.findViewById(R.id.dateff);

        }
    }
}
