package com.example.daibatesmyapp.ContentFrag;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;

public class ContentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        getSupportActionBar().setTitle("          ความรู้เกี่ยวกับโรคเบาหวาน");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    public void onClick1(View view) {
        Intent inte = new Intent(this, Content1Activity.class);
        startActivity(inte);
    }
    public void onClick2(View view) {
        Intent inte = new Intent(this,Content2Activity.class);
        startActivity(inte);
    }
    public void onClick3(View view) {
        Intent inte = new Intent(this,Content3Activity.class);
        startActivity(inte);
    }
    public void onClick4(View view) {
        Intent inte = new Intent(this,Content4Activity.class);
        startActivity(inte);
    }
    public void backhome(View view) {
        Intent inte = new Intent(this, HomeActivity.class);
        startActivity(inte);
    }
}
