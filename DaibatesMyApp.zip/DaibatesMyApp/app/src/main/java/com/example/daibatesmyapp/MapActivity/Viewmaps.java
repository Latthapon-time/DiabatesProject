package com.example.daibatesmyapp.MapActivity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;
import com.example.daibatesmyapp.reminder.Upandremove;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;




public class Viewmaps extends AppCompatActivity {
    private RecyclerView FindFriendsRecyclerList;
    private DatabaseReference UsersRef;
    private FirebaseAuth auth = FirebaseAuth.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewmaps);
        setTitle("  โรงพยาบาลที่เกี่ยวกับโรคเบาหวาน");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        UsersRef = FirebaseDatabase.getInstance().getReference().child("hospital");

        FindFriendsRecyclerList = (RecyclerView) findViewById(R.id.myRecycleView);
        FindFriendsRecyclerList.setLayoutManager(new LinearLayoutManager(this));
    }
    @Override
    public void onBackPressed() {

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onStart()
    {
        super.onStart();

        FirebaseRecyclerOptions<Getmaps> options =
                new FirebaseRecyclerOptions.Builder<Getmaps>()
                        .setQuery(UsersRef, Getmaps.class)
                        .build();

        FirebaseRecyclerAdapter<Getmaps, FindFriendViewHolder> adapter =
                new FirebaseRecyclerAdapter<Getmaps, FindFriendViewHolder>(options) {
                    @Override
                    protected void onBindViewHolder(@NonNull FindFriendViewHolder holder, final int position, @NonNull Getmaps model)
                    {
                        holder.userName.setText(model.gethospitalname());
//                        holder.userlati.setText(model.getLati());
                       holder.userlongti.setText(model.getTel());




                        holder.itemView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                final String reminderId = getRef(position).getKey();
                                Intent intent = new Intent(Viewmaps.this, MapsDetail.class);
                               intent.putExtra("reminderId", reminderId);
                                startActivity(intent);
                            }
                        });




                    }

                    @NonNull
                    @Override
                    public FindFriendViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
                    {
                        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.lis_maps, viewGroup, false);
                        FindFriendViewHolder viewHolder = new FindFriendViewHolder(view);
                        return viewHolder;
                    }
                };

        FindFriendsRecyclerList.setAdapter(adapter);

        adapter.startListening();
    }



    public static class FindFriendViewHolder extends RecyclerView.ViewHolder
    {

        TextView userName;

        TextView userlati;

        TextView userlongti;

        TextView usertel;


        public FindFriendViewHolder(@NonNull View itemView)
        {
            super(itemView);


            userName = itemView.findViewById(R.id.view_head);
            userlati = itemView.findViewById(R.id.latijut);
            userlongti = itemView.findViewById(R.id.aaat);

        }
    }
}