package com.example.daibatesmyapp.reminder;



import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.daibatesmyapp.R;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class AdapterView extends RecyclerView.Adapter<AdapterView.ViewHolder> {






    private List<GetRemider> listItems;
    private Context context;

    public AdapterView(List<GetRemider> listItems, Context context) {
        this.listItems = listItems;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
       View v = LayoutInflater.from(parent.getContext())
               .inflate(R.layout.list_remider, parent, false);
       return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        GetRemider listItem = listItems.get(position);

        holder.textViewHead.setText(listItem.getSugar_level());
        holder.textViewDesc.setText(listItem.getSugar_date());
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        public TextView textViewHead;
        public TextView textViewDesc;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewHead = (TextView) itemView.findViewById(R.id.view_head);
            textViewDesc = (TextView) itemView.findViewById(R.id.view_ReminderContent);
        }
    }
}
