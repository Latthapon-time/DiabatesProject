package com.example.daibatesmyapp.Noti;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.Main2Activity;
import com.example.daibatesmyapp.MapActivity.Viewmaps;
import com.example.daibatesmyapp.R;
import com.example.daibatesmyapp.reminder.ViewReminder;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class UinotiActivity extends AppCompatActivity {
    public static String MEDICAL ="";
    public static String MEDICAL2 ="";
    TimePicker timePicker;
    public static long hour,minute, hourOfDay,mOfDay, diff,repert;


    private   String namename;


    EditText editText2;
    Button button;

    FirebaseAuth auth;
    DatabaseReference mDatabaseReference,mfirebase;
    Spinner dropdown_repert,sp_medicine;
    String textrepert;

    ArrayList<String> spinnerDataLits;


    //TextView editText2;
    public static int count  = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uinoti);
        setTitle("         เพิ่มรายการยาที่ต้องการแจ้งเตือน");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        //สร้่าง list ยา
        sp_medicine = findViewById(R.id.sp_medicine);
//        final String[] items_medicine = new String[]{"Metformin",
//                "Repaglinide",
//                "DPP-4Inhibitors",
//                "Acarbose" ,
//                "Bile Acid Sequestrants",
//                "Sulfonylurea",
//                "alphaglucidase" ,
//                "Troglitazone",
//                "Meglitinides"};
        //ดึงรายการยา มาจากเบท
        spinnerDataLits = new ArrayList<>();
        final ArrayAdapter<String> adapter_medicine = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, spinnerDataLits);

mfirebase = mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("addmedical");
mfirebase.addValueEventListener(new ValueEventListener() {
    @Override
    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
        for (DataSnapshot item:dataSnapshot.getChildren()){

            spinnerDataLits.add(item.child("medicalname").getValue().toString());

        }
        adapter_medicine.notifyDataSetChanged();
    }

    @Override
    public void onCancelled(@NonNull DatabaseError databaseError) {

    }
});
        sp_medicine.setAdapter(adapter_medicine);

//0[



        editText2= findViewById(R.id.editText2);


        sp_medicine.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0){
                    //Metformin
                    editText2.setText("ยาจะลดการดูดซึมของน้ำตาลจากทางเดินอาหาร และยับยั้งการสร้างกลูโคสที่ตับ อาจใช้เป็นยาเดี่ยว หรือใช้ร่วมกับยารักาเบาหวานชนิดอื่น");
                }
                if (position == 1){
                    //Repaglinide
                    editText2.setText("โดยยานี้จะใช้ร่วมกับการควบคุมอาหารและการออกกำลังกายเพื่อควบคุมระดับน้ำตาลในเลือด");
                }
                if (position == 2){
                    //DPP-4 Inhibitors
                    editText2.setText("ยากลุ่มนี้รับประทานวันละครั้ง ยานี้ออกฤทธิ์โดยการเพิ่มอินซูลินหลังจากรับประทานอาหาร และลดการสร้างน้ำตาล");
                }
                if (position == 3){
                    //Acarbose
                    editText2.setText("เป็นยาที่นำมาใช้รักษาผู้ป่วยเบาหวานโดยลดการดูดซึมสารอาหารที่ลำไส้เล็กส่วนต้น");
                }
                if (position == 4){
                    //Bile Acid Sequestrants
                    editText2.setText("ยานี้ใช้ลดไขมันในเลือด แต่เมื่อใช้ร่วมกับยาลดน้ำตาลจะช่วยทำให้น้ำตาลต่ำลง");
                }
                if (position == 5){
                    //Sulfonylurea
                    editText2.setText("ยาในกลุ่มนี้รับประทานวันละ1-2 ครั้ง การออกฤทธิ์ของยา ยานี้ออกฤทธิ์กระตุ้นตับอ่อนให้ผลิตอินซูลินเพิ่มขึ้น");
                }
                if (position == 6){
                    //alphaglucidase
                    editText2.setText("ยานี้ให้รับประทานยาพร้อมอาหารคำแรก หากไม่ได้รับประทานอาหารก็ไม่ต้องรับประทานยา ยานี้ออฤทธิ์โดยการลดการดูดซึมน้ำตาลในลำไส้");
                }
                if (position == 7){
                    //Troglitazone
                    editText2.setText("ยานี้รับประทานวันละครั้งให้ตรงเวลา ยานี้จะเพิ่มการตอบสนองของร่างกายต่ออินซูลิน");
                }
                if (position == 8){
                    //Meglitinides
                    editText2.setText("ยานี้รับประทานพร้อมอาหาร หากไม่ได้รับประทานอาหารไม่ควรจะใช้ยา ยาชนิดนี้จะกระตุ้นการสร้างอินซูลินหลังจากรับประทานอาหาร");
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //กรอกรายละเอียดยา


        button = findViewById(R.id.button1);
        timePicker = findViewById(R.id.datePicker1);
        timePicker.setIs24HourView(true);
        //สร้าง list รีพีส
        dropdown_repert = findViewById(R.id.spinner1);
        final String[] items = new String[]{"15 นาที", "30 นาที"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown_repert.setAdapter(adapter);


        auth =  FirebaseAuth.getInstance();




        mDatabaseReference = FirebaseDatabase.getInstance().getReference().child("medication_plan").child(auth.getCurrentUser().getUid());

        //เมื่อกดปุ่ม จะเริ่มทำงานดังนี้
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String title1 = sp_medicine.getSelectedItem().toString();
                MEDICAL = title1;
                String title2 = editText2.getText().toString();
                MEDICAL2 = title2;

                //**เงื่อนไข**ห้ามเเลือกยาซ้ำ
                mDatabaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        boolean control = false;

                       for (DataSnapshot childDataSnapshot : dataSnapshot.getChildren()){
                           String a = childDataSnapshot.child("medical").getValue().toString();
                            boolean check = a.equals(title1);
                            if(check){

                               control = true;

                                break;

                           }
                       }


                       if(control == false) {
                           //เงื่อนไข list ยา
                           switch (sp_medicine.getSelectedItem().toString()) {
                               case "Metformin":
//                                   Toast.makeText(getApplicationContext(), "Metformin", Toast.LENGTH_LONG).show();
                                   String rank1 = "Metformin";
                                   Ranknoti_medicine(rank1);

                                   break;
                               case "Repaglinide":
                                   Toast.makeText(getApplicationContext(), "Repaglinide", Toast.LENGTH_LONG).show();
                                   String rank2 = "Repaglinide";
                                   Ranknoti_medicine(rank2);

                                   break;
                               case "DPP-4Inhibitors":
                                   Toast.makeText(getApplicationContext(), "DPP-4 Inhibitors ", Toast.LENGTH_LONG).show();
                                   String rank3 = "DPP-4Inhibitors";
                                   Ranknoti_medicine(rank3);
                                   break;

                               case "Acarbose":
                                   Toast.makeText(getApplicationContext(), "Acarbose", Toast.LENGTH_LONG).show();
                                   String rank4 = "Acarbose";
                                   Ranknoti_medicine(rank4);
                                   break;

                               case "Bile Acid Sequestrants":
                                   Toast.makeText(getApplicationContext(), "Bile Acid Sequestrants", Toast.LENGTH_LONG).show();
                                   String rank5 = "Bile Acid Sequestrants";
                                   Ranknoti_medicine(rank5);
                                   break;

                               case "Sulfonylurea":
                                   Toast.makeText(getApplicationContext(), "Sulfonylurea", Toast.LENGTH_LONG).show();
                                   String rank6 = "Sulfonylurea";
                                   Ranknoti_medicine(rank6);
                                   break;

                               case "alphaglucidase":
                                   Toast.makeText(getApplicationContext(), "alphaglucidase", Toast.LENGTH_LONG).show();
                                   String rank7 = "alphaglucidase";
                                   Ranknoti_medicine(rank7);
                                   break;

                               case "Troglitazone":
                                   Toast.makeText(getApplicationContext(), "Troglitazone", Toast.LENGTH_LONG).show();
                                   String rank8 = "Troglitazone";
                                   Ranknoti_medicine(rank8);
                                   break;

                               case "Meglitinides":
                                   Toast.makeText(getApplicationContext(), "Meglitinides", Toast.LENGTH_LONG).show();
                                   String rank9 = "Meglitinides";
                                   Ranknoti_medicine(rank9);
                                   break;

                           }
                       }
//                       else {
//                           Toast.makeText(getApplicationContext(),"ไม่ได้",Toast.LENGTH_LONG).show();
//                       }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

//                count=count+1;
//                Toast.makeText(getApplicationContext(),"...."+repert,Toast.LENGTH_LONG).show();
//                //Toast.makeText(getApplicationContext(),"เริ่มทำการแจ้งเตือน"+count,Toast.LENGTH_LONG).show();
//                if(count==1){
//                    String title1 = editText1.getText().toString();
//                    MEDICAL = title1;
//                    String title2 = editText2.getText().toString();
//                    MEDICAL2 = title2;
//
//                    //เเซ็ตเวลา
//                    if (Build.VERSION.SDK_INT >= 23){
//                        hour = timePicker.getHour();
//                        minute = timePicker.getMinute();
//                    }else{
//                        hour = timePicker.getCurrentHour();
//                        minute = timePicker.getCurrentMinute();
//                    }
//                    Calendar cur = Calendar.getInstance();
//                    Calendar calendar = Calendar.getInstance();
//                    hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
//                    mOfDay = calendar.get(Calendar.MINUTE);
//
//                    //การหานาที
//                    diff = (hour-hourOfDay)*60  + (minute - mOfDay) ;
//

//                }
//                else  if(count == 2){
//                    String title1 = editText1.getText().toString();
//                    MEDICAL = title1;
//                    String title2 = editText2.getText().toString();
//                    MEDICAL2 = title2;
//
//                    //เเซ็ตเวลา
//                    if (Build.VERSION.SDK_INT >= 23){
//                        hour = timePicker.getHour();
//                        minute = timePicker.getMinute();
//                    }else{
//                        hour = timePicker.getCurrentHour();
//                        minute = timePicker.getCurrentMinute();
//                    }
//                    Calendar cur = Calendar.getInstance();
//                    Calendar calendar = Calendar.getInstance();
//                    hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
//                    mOfDay = calendar.get(Calendar.MINUTE);
//
//                    //การหานาที
//                    diff = (hour-hourOfDay)*60  + (minute - mOfDay) ;
//
//                    startActivity(new Intent(UinotiActivity.this, StartNoti2Activity.class));
//                    finish();
//                }
//                //Add--ข้อมูลเข้าเบท
//                String medical = editText1.getText().toString().trim();
//
//
//                if (!TextUtils.isEmpty(medical)) {
//                    Createaddnoti();
//
//                } else {
//                    Snackbar.make(view, "Please Fill empty fields", Snackbar.LENGTH_SHORT).show();
//                }
           }
       });


        //ปุ่ม
        final BottomNavigationView navView = findViewById(R.id.bottomNavigationView2);
        Menu menu = navView.getMenu();
        MenuItem menuItem = menu.getItem(2);
        menuItem.setChecked(true);

        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem1) {
                switch (menuItem1.getItemId()) {
                    case R.id.navigation_home:


                        Toast.makeText(UinotiActivity.this, "หน้าหลัก", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(UinotiActivity.this, HomeActivity.class));
                        break;
                    case R.id.navigation_dashboard:
                        Toast.makeText(UinotiActivity.this, "บันทึกค่าน้ำตาล", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(UinotiActivity.this, ViewReminder.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_notifications:
                        Toast.makeText(UinotiActivity.this, "เตือนการกินยา", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(UinotiActivity.this, UinotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_viewnoti:
                        Toast.makeText(UinotiActivity.this, "รายการที่บันทึกแจ้งเตือน", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(UinotiActivity.this, ViewNotiActivity.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                    case R.id.navigation_map:
                        Toast.makeText(UinotiActivity.this, "แผนที่", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(UinotiActivity.this, Viewmaps.class));
                        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                        break;
                }
                return false;
            }
        });
    }

    @Override
    public void onBackPressed() {

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }



    private void Ranknoti_medicine(String rank) {
        textrepert = dropdown_repert.getSelectedItem().toString();
        if(textrepert.equals("15 นาที")){
            textrepert="15";
        }
        else if(textrepert.equals("30 นาที")){
            textrepert="30";
        }
        repert = Long.parseLong(textrepert);
        //กำหนดเวลาเตือน
        if (Build.VERSION.SDK_INT >= 23){
            hour = timePicker.getHour();
            minute = timePicker.getMinute();
        }else{
            hour = timePicker.getCurrentHour();
            minute = timePicker.getCurrentMinute();
        }
            Calendar cur = Calendar.getInstance();
            Calendar calendar = Calendar.getInstance();
            hourOfDay = calendar.get(Calendar.HOUR_OF_DAY);
            mOfDay = calendar.get(Calendar.MINUTE);
        //การแปลงจากชั่วเป็นนาที
        diff = (hour-hourOfDay)*60  + (minute - mOfDay) ;
        switch (rank.toString()){
            case "Metformin":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, Main2Activity.class));
                finish();
                break;
            case "Repaglinide":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti2Activity.class));
                finish();
                break;
            case "DPP-4Inhibitors":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti3Activity.class));
                finish();
                break;
            case "Acarbose":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti4Activity.class));
                finish();
                break;
            case "Bile Acid Sequestrants":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti5Activity.class));
                finish();
                break;
            case "Sulfonylurea":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti6Activity.class));
                finish();
                break;
            case "alphaglucidase":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti7Activity.class));
                finish();
                break;
            case "Troglitazone":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti8Activity.class));
                finish();
                break;
            case "Meglitinides":
                Createaddnoti();
                startActivity(new Intent(UinotiActivity.this, StartNoti9Activity.class));
                finish();
                break;

        }

    }

    private void Createaddnoti() {

        String Head = sp_medicine.getSelectedItem().toString();
        String reminder = editText2.getText().toString().trim();
        String today ;


        Date date  = Calendar.getInstance().getTime();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        today = formatter.format(date);
        //check id + add
        if (auth.getCurrentUser() != null) {
String name = namename;
            String id = mDatabaseReference.push().getKey();
            GetNoti Reminder = new GetNoti(Head,reminder,today);
            mDatabaseReference.child(id).setValue(Reminder);
//            editText1.setText("");
            //txtdatesugaShedu.setText("");
//            Toast.makeText(AddReminder.this, "Add " , Toast.LENGTH_SHORT).show();
//            Intent newIntent = new Intent(AddReminder.this, HomeActivity.class);
//            startActivity(newIntent);
        } else {
            Toast.makeText(this, "User not Login ", Toast.LENGTH_SHORT).show();
        }
    }
    public void backhome(View view) {
        Intent inte = new Intent(this, HomeActivity.class);
        startActivity(inte);
    }

}