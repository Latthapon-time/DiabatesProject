package com.example.daibatesmyapp.ContentFrag;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import com.example.daibatesmyapp.HomeActivity;
import com.example.daibatesmyapp.R;

public class Content1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content1);
        setTitle("          ความรู้เกี่ยวกับโรคเบาหวาน");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, ContentActivity.class);
            startActivity(inte);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
