package com.example.daibatesmyapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {

    EditText FnameValue,GenderValue,bloodgrpValue,AddressValue,phoneValue,profileDob;
    Button btnEditt, btnsave;
    DatabaseReference mDatabaseReference = FirebaseDatabase.getInstance().getReference("users");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
//        auid = findViewById(R.id.txt_uid);
//        bemail = findViewById(R.id.txt_email);
//        cname = findViewById(R.id.txt_name);
//        egender = findViewById(R.id.txt_gender);
//        ftell = findViewById(R.id.txt_tell);
       // Toolbar toolbar =  findViewById(R.id.profileAppBar);
        //setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("                    โปรไฟล์");

        FnameValue=findViewById(R.id.FnameValue);
        //EditProfile=findViewById(R.id.EditProfile);
        GenderValue=findViewById(R.id.genderValue);
        bloodgrpValue=findViewById(R.id.bloodgrpValue);
        AddressValue=findViewById(R.id.AddressValue);
        phoneValue=findViewById(R.id.MobileValue);
        profileDob=findViewById(R.id.profileDob);
        btnEditt = findViewById(R.id.Update);
        btnsave = findViewById(R.id.btneditttt);

        //auid.setText(auth.getCurrentUser().getUid());
        //String uid = auth.getCurrentUser().getUid();
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//       bemail.setText(user.getEmail());
//       auid.setText(user.getUid());
        String uid = user.getUid();
        fetchData(uid);
        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnEditt.setVisibility(View.VISIBLE);
                FnameValue.setEnabled(true);
                FnameValue.setCursorVisible(true);
                profileDob.setEnabled(true);
                phoneValue.setEnabled(true);
                GenderValue.setBackgroundColor(getResources().getColor(R.color.md_grey_300));
                GenderValue.setTextColor(Color.GRAY);
                AddressValue.setBackgroundColor(getResources().getColor(R.color.md_grey_300));
                AddressValue.setTextColor(Color.GRAY);
                btnEditt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String tel = phoneValue.getText().toString();
                        String birthday = profileDob.getText().toString();
                        if (tel.length() < 9 || tel.length() > 11) {
                            phoneValue.setError("กรุณากรอกเบอร์โทรศัพท์ 10 ตัวเท่านั้น");
                        }
                        else if (birthday.matches("")) {
                            profileDob.setError("กรุณาเลือกวันเกิด");
                        }else {
                        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
                        DatabaseReference dbrefUser = FirebaseDatabase.getInstance().getReference("users").child(uid);
                        String name = FnameValue.getText().toString();

                        String address = AddressValue.getText().toString();
                        String phone = phoneValue.getText().toString();
                        String dob = profileDob.getText().toString();

                        Map info = new HashMap();
                        info.put("user_name", name);
                        info.put("email", address);
                        info.put("tell", phone);
                        info.put("birthday", dob);

                        if (TextUtils.isEmpty(FnameValue.getText()) || TextUtils.isEmpty(AddressValue.getText())
                                || TextUtils.isEmpty(phoneValue.getText())
                                || (TextUtils.isEmpty(phoneValue.getText()))) {
                            Toast.makeText(ProfileActivity.this, "กรุณากรอกข้อมูลให้ครบ", Toast.LENGTH_SHORT).show();

                        } else {

                            dbrefUser.updateChildren(info, new DatabaseReference.CompletionListener() {
                                @Override
                                public void onComplete(@Nullable DatabaseError databaseError, @NonNull DatabaseReference databaseReference) {
                                    if (databaseError == null) {
                                        Toast.makeText(ProfileActivity.this, "บันทึกข้อมูลสำเร็จ", Toast.LENGTH_SHORT).show();
                                        btnEditt.setVisibility(View.GONE);
                                        FnameValue.setEnabled(false);
                                        FnameValue.setCursorVisible(false);
                                        AddressValue.setEnabled(false);
                                        phoneValue.setEnabled(false);
                                        profileDob.setEnabled(false);

                                        GenderValue.setBackgroundColor(getResources().getColor(R.color.md_white_1000));
                                        GenderValue.setTextColor(Color.BLACK);
                                        AddressValue.setTextColor(Color.BLACK);
                                        AddressValue.setBackgroundColor(getResources().getColor(R.color.md_white_1000));


                                    } else {
                                        Toast.makeText(ProfileActivity.this, "ไม่สามารถบันทึกข้อมูลได้", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                        }

                    }
                    }
                });

            }
        });

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            Intent inte = new Intent(this, HomeActivity.class);
            startActivity(inte);
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right);
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void fetchData(String u_id) {
        mDatabaseReference.child(u_id).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String fnname = dataSnapshot.child("user_name").getValue().toString();
                String sex = dataSnapshot.child("sex").getValue().toString();
                String tell = dataSnapshot.child("tell").getValue().toString();
                String dob = dataSnapshot.child("birthday").getValue().toString();

                final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                FnameValue.setText(fnname);
                GenderValue.setText(sex);

                AddressValue.setText(user.getEmail());
                phoneValue.setText(tell);
                profileDob.setText(dob);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


    }
}