package com.example.daibatesmyapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.time.Instant;

public class MainActivity extends AppCompatActivity {

    private Button btRegis;
    private Button btLogin;
    private EditText edUser;
    private EditText edPass;
    private static final String TAG = "MainActivity";
    String url;
    public static final String MyPREFERENCES = "MyPrefs";
    SharedPreferences sharedpreferences;
    FirebaseAuth auth;
    ProgressDialog progressDialog;
    private Button btForget;
//    private EditText edCon;
//    private Button btOk;
//    private ImageView imClose;
//    private Button btSend;
    private TextView tvRegis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();

        auth = FirebaseAuth.getInstance();
        btLogin = (Button) findViewById(R.id.btLogin);
        btForget = (Button) findViewById(R.id.btForget);
        edUser = (EditText) findViewById(R.id.edUser);
        edPass = (EditText) findViewById(R.id.edPass);
        tvRegis = (TextView) findViewById(R.id.tvRegis);


        tvRegis.setPaintFlags(tvRegis.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);


        // Progress dialog10
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);

        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userLogin();
            }
        });
        btForget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ForgetPasswordActivity.class);
                startActivity(i);
            }
        });

        tvRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, RegisterUserActivity.class);
                startActivity(i);
                finish();
            }
        });

    }


    private void showDialog() {
        if (!progressDialog.isShowing())
            progressDialog.show();
        progressDialog.setMessage("Wait...");
    }

    private void hideDialog() {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }



    private void userLogin() {
        if (TextUtils.isEmpty(edUser.getText()) || TextUtils.isEmpty(edPass.getText())) {
            Toast.makeText(MainActivity.this, "กรุณากรอก อีเมล และ รหัสผ่าน", Toast.LENGTH_SHORT).show();
        } else {
            showDialog();
            auth.signInWithEmailAndPassword(edUser.getText().toString(), edPass.getText().toString())
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                hideDialog();
                                Intent intent = new Intent(MainActivity.this,HomeActivity.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                                finish();
                            } else {
                                hideDialog();
                                Toast.makeText(MainActivity.this, "ไม่มีบัญชีผู้ใช้นี้ โปรดสมัครสมาชิก", Toast.LENGTH_SHORT).show();
                            }

                        }
                    });
        }
    }
}


