package com.example.daibatesmyapp.Noti;

public class Get_nameMedical {
    private String name;

    public Get_nameMedical(String NameMedi){
        name = NameMedi;
    }
    public String getmedicalname() {
        return name;
    }
    public void setmedicalname(String head) {
        this.name = head;
    }
}
